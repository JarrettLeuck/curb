from django import forms
from .models import Data, Choice, CustomUser, Post, Map

from django.contrib.auth.forms import UserCreationForm, UserChangeForm

class CustomUserCreationForm(UserCreationForm):

	class Meta(UserCreationForm):
		model = CustomUser
		fields = ('email', 'name')

class CustomUserChangeForm(UserChangeForm):
	
	class Meta:
		model = CustomUser
		fields = ('email', 'name')

class CitationForm(forms.ModelForm):
        class Meta:
                model = Data
                fields = [
                        'Ticket_Num',
                        'Issue_date',
                        'Issue_time',
                        'Meter_ID',
                        'State_Plate',
                        'State_exp_date',
                        'Make',
                        'Body_style',
                        'Color',
                        'Location',
                        'Violation_Code',
                        'Violation_desription',
                        'Fine_Amount',
                        'Longitude',
                        'Latitude',
                        'Email'
		]
                help_texts = {
                        'Ticket_Num': '*',
                        'Location': '*',
                        'Email': '*'
                }

class UserForm(forms.ModelForm):
	password = forms.CharField(widget=forms.PasswordInput)
	class Meta:
		model = Choice
		fields = [
			'name',
			'email',
			'password'
		]

class PostForm(forms.ModelForm):
	class Meta:
		model = Post
		fields = [
			'text',
			'username',
			'ID_del'
		]
		help_texts = {
			'text': '(*, can be anything when deleting)',
			'username': 'User email address. (*)',
			'ID_del': 'Message ID to delete.'
		}

class MapForm(forms.ModelForm):
	class Meta:
		model = Map
		fields = [
			'date',
			'time'
			]
		help_texts = {
			'date': '*MMDDYYYY',
			'time': '*Ex:13:30'
		}
