from django.db import models
import uuid

# Create your models here.
from django.contrib.auth.models import AbstractBaseUser
from django.contrib.auth.models import PermissionsMixin
from django.utils.translation import gettext_lazy as _
from django.utils import timezone

from .managers import LoginManager

class CustomUser(AbstractBaseUser, PermissionsMixin):
	email = models.EmailField(_('email address'), unique=True)
	is_staff = models.BooleanField(default=False)
	is_active = models.BooleanField(default=True)
	date_joined = models.DateTimeField(default=timezone.now)
	name = models.CharField(max_length=200)


	REQUIRED_FIELDS = ['name']
	USERNAME_FIELD = 'email'

	objects = LoginManager()

	def __str__(self):
		return self.email


class Choice(models.Model):
	name = models.CharField(max_length = 200)
	email = models.EmailField(max_length=200, primary_key = True)
	password = models.CharField(max_length = 200)
	class Meta:
		managed = False
		db_table = "UserID"

class Data(models.Model):
	Ticket_Num = models.IntegerField(primary_key = True)
	Issue_date = models.DateTimeField(null=True, blank=True)
	Issue_time = models.IntegerField(null=True, blank=True)
	Meter_ID = models.CharField(max_length=200, null=True, blank=True)
	State_Plate = models.CharField(max_length=200, null=True, blank=True)
	State_exp_date = models.CharField(max_length=200, null=True, blank=True)
	Make = models.CharField(max_length=200, null=True, blank=True)
	Body_style = models.CharField(max_length=200,null=True, blank=True)
	Color = models.CharField(max_length=200,null=True, blank=True)
	Location = models.CharField(db_index=True, max_length=200)
	Violation_Code = models.CharField(max_length=200,null=True, blank=True)
	Violation_desription = models.CharField(max_length=200,null=True, blank=True)
	Fine_Amount = models.IntegerField(default=None, null=True, blank=True)
	Longitude = models.IntegerField(null=True, blank=True)
	Latitude = models.IntegerField(null=True, blank=True)
	Email = models.EmailField(null=True, blank=True)
	class Meta:
		managed = False
		db_table = "Citation_ID"

class Post(models.Model):
	text = models.TextField()
	username = models.EmailField(db_index=True)
	ID_del = models.IntegerField(null=True, blank=True)
	like = models.IntegerField(default=0, blank=True)
	dislike = models.IntegerField(default=0, blank=True)

class Map(models.Model):
        longitude = models.FloatField()
        latitude = models.FloatField()
        date = models.DateField()
        time = models.TimeField()
