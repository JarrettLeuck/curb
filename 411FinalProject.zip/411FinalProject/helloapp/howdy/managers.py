from django.contrib.auth.base_user import BaseUserManager
from django.utils.translation import ugettext_lazy as _



class LoginManager(BaseUserManager):
	def create_user(self, email, password1, name):

		if not email:
			raise ValueError(_("User must have email!"))

		email =	self.normalize_email(email)
		user = self.model(
			email=email,
			name=name,
		)
		user.set_password(password1)
		user.save()
		return user

	def create_superuser(self, email, password1, name):
		user = self.create_user(email, password1, name)
		user.is_staff = True
		user.is_superuser = True
		user.is_active = True
		user.save()
		return user

