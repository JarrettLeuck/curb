from django.shortcuts import render, get_object_or_404
from django.template import loader
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.urls import reverse
import operator
from django.db.models import Q
from django.views.generic import ListView
from django.db import connection
from django.contrib.auth import authenticate, login, get_user_model, logout
from django.db import transaction

# Create your views here.
# howdy/views.py
from django.views.generic import TemplateView
from .models import Choice
from .models import Data, Post
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
from django.urls import reverse_lazy
from django.views import generic
import datetime
import math
#import pyproj

# import forms here
from .forms import CitationForm, UserForm, CustomUserCreationForm, PostForm, MapForm

# Create your views here.
# class HomePageView(TemplateView):
#     def get(self, request, **kwargs):
#         return render(request, 'index.html', context=None)
def test(request):
    return render(request, 'test.html', context=context)
def index(request):
    users = Choice.objects.all().count()
    context = { 
    'users': users
    }
    return render(request, 'index.html', context=context)

def about(request):
	return render(request, 'about.html')

def contact(request):
	return render(request, 'contact.html')

def citation_search(request):
    if request.method == 'POST':
        ticket = request.POST.get('ticket_num', None)
        try:
            values = Data.objects.get(Ticket_Num = ticket)
        except Data.DoesNotExist:
            values = None
        if values != None:
            context = {'values': values}
            final = search_result(request, context)
        else:
            final = error(request)
    else:
        context = {}
        final = render(request, "citations_search.html", context)
    return final

def search_result(request, context):
    return render(request, 'result.html', context)

def delete(request):
    if request.method == 'POST':
        ticket = request.POST.get('ticket_num', None)
        try:
            values = Data.objects.get(Ticket_Num = ticket)
        except Data.DoesNotExist:
            values = None
        if values != None:
            context = {
                'ticket': ticket
            }
            values.delete()
            final = delete_success(request, context)
        else:
            final = error(request)
    else:
        context = {}
        final = render(request, 'delete.html', context)
    return final

def delete_success(request, context):
	return render(request, 'delete_success.html', context)

def error(request):
	return render(request, 'error.html')

def citation_create_form(request):
	form_temp = CitationForm(None)
	context = {
		'form': form_temp
	}
	final = render(request, "citation_create.html", context)
	if request.method == 'POST' and 'submit' in request.POST:
		form = CitationForm(request.POST or None)
		if form.is_valid():
			form.save()	
		else:
			context = {
			'form': form
			}
			final = render(request, "citation_create.html", context)
	if request.method == 'POST' and 'update' in request.POST:
		print('here2')
		form_update = CitationForm(request.POST or None)
		print(form_update.is_valid())
		try:
			obj = Data.objects.get(Ticket_Num = request.POST.get('Ticket_Num'))
		except Data.DoesNotExist:
			obj = None
			final = error(request)
		if obj != None:
			print('Here')
			if request.POST.get('Issue_date') == '' and obj.Issue_date == None:
				obj.Issue_date = None
			elif request.POST.get('Issue_date') != '':
				obj.Issue_date = request.POST.get('Issue_date')
			if request.POST.get('Issue_time') == '' and obj.Issue_time == None:
				obj.Issue_time = None
			elif request.POST.get('Issue_time') != '':
				obj.Issue_time = request.POST.get('Issue_time')
			if request.POST.get('Meter_ID') == ''and obj.Meter_ID == None:
				obj.Meter_ID = None
			elif request.POST.get('Meter_ID') != '':
				obj.Meter_ID = request.POST.get('Meter_ID')
			if request.POST.get('State_Plate') == '' and obj.State_Plate == None:
				obj.State_Plate = None
			elif request.POST.get('State_Plate') != '':
				obj.State_Plate = request.POST.get('State_Plate')
			if request.POST.get('State_exp_date') == '' and obj.State_exp_date == None:
				obj.State_exp_date = None
			elif request.POST.get('State_exp_date') != '':
				obj.State_exp_date = request.POST.get('State_exp_date')
			if request.POST.get('Make') == '' and obj.Make == None:
				obj.Make = None
			elif request.POST.get('Make') != '':
				obj.Make = request.POST.get('Make')
			if request.POST.get('Bodye_style') == '' and obj.Body_style == None:
				obj.Body_style = None
			elif request.POST.get('Body_style') != '':
				obj.Body_style = request.POST.get('Body_style')
			if request.POST.get('Color') == '' and obj.Color == None:
				obj.Color = None
			elif request.POST.get('Color') != '':
				obj.Color = request.POST.get('Color')
			if request.POST.get('Location') == '' and obj.Location == None:
				obj.Location = None
			elif request.POST.get('Location') != '':
				obj.Location = request.POST.get('Location')
			if request.POST.get('Violation_Code') == '' and obj.Violation_Code == None:
				obj.Violation_Code = None
			elif request.POST.get('Violation_Code') != '':
				obj.Violation_Code = request.POST.get('Violation_Code')
			if request.POST.get('Violation_desription') == '' and obj.Violation_desription == None:
				obj.Violation_desription = None
			elif request.POST.get('Violation_desription') != '':
				obj.Violation_desription = request.POST.get('Violation_desription')
			if request.POST.get('Fine_Amount') == '' and obj.Fine_Amount == None:
				obj.Fine_Amount = None
			elif request.POST.get('Fine_Amount') != '':
				obj.Fine_Amount = request.POST.get('Fine_Amount')
			if request.POST.get('Longitude') == '' and obj.Longitude == None:
				obj.Longitude = None
			elif request.POST.get('Longitude') != '':
				obj.Longitude = request.POST.get('Longitude')
			if request.POST.get('Latitude') == '' and obj.Latitude == None:
				obj.Latitude = None
			elif request.POST.get('Latitude') != '':
				obj.Latitude = request.POST.get('Latitude')
			if request.POST.get('Email') == '' and obj.Email == None:
				obj.Email = None
			elif request.POST.get('Email') != '':
				obj.Email = request.POST.get('Email')
			obj.save()

	return final

def citations(request):
	cit_data = Data.objects.all().count()
	context = {
	'cit_data' : cit_data
	}
	return render(request, 'citations.html', context=context)

def profile_view(request):
	email = request.user
	citations = []
	try:
		for x in Data.objects.filter(Email=email):
			citations.append(x)
	except Data.DoesNotExist:
		citations = None
		context = {}
		return render(request, 'profile.html', context)
	context = {
		'citations': citations
	}
	return render(request, 'profile.html', context)

def logout_view(request):
	logout(request)
	return redirect('index')


class SignUp(generic.CreateView):
	form_class = CustomUserCreationForm
	success_url = reverse_lazy('login')
	template_name = 'signup.html'
	
	def form_valid(self, form):
		valid = super().form_valid(form)
		email, password = form.cleaned_data.get('email'), form.cleaned_data.get('password')
		#user = authenticate(email=email, password=password)
		user = form.save()
		login(self.request, user)
		return valid


def LoginRequest(request):
	form = UserForm(request.POST or None)
	email = request.POST.get('email')
	password = request.POST.get('password')
	active = authenticate(username=email, password=password)
	if active:
		User = get_user_model()
		url = reverse_lazy('profile')
		login(request, active)
		return HttpResponseRedirect(url)
	return render(request, 'login.html',{'form': form})

def messages(request):
	def custom_sort(t):
		return t.like
	form_temp = PostForm(None)
	if request.method == "POST" and 'Like' in request.POST:
		z = Post.objects.get(id=request.POST.get("row_id", ""))
		z.like = z.like + 1
		z.save()
	if request.method == "POST" and 'Dislike' in request.POST:
		z = Post.objects.get(id=request.POST.get("row_id", ""))
		z.like = z.like - 1
		z.save()
	if request.method == "POST" and 'submit' in request.POST:
		form = PostForm(request.POST)
		if form.is_valid():
			form.save()
	if request.method == "POST" and 'delete' in request.POST:
		m = request.POST.get('ID_del', None)
		try:
			del_msg = Post.objects.get(id=m)
		except Post.DoesNotExist:
			del_msg = None
		if del_msg != None:
			del_msg.delete()
	message_board = []
	try:
		for x in Post.objects.all():
			message_board.append(x)
		message_board.sort(key=custom_sort, reverse=True)
	except Post.DoesNotExist:
		message_board = None
	context = {
		'form': form_temp,
		'msgs': message_board
	}
	final = render(request, 'messages.html', context)
	return final

def map(request):
    form = MapForm(None)
    context = {
        'form': form
    }
    longitude = request.POST.get('longitude', None)
    latitude = request.POST.get('latitude', None)
    time = request.POST.get('time', None)
    date = request.POST.get('date', None)
    #cleaning up data inputs
    if(date and date.isnumeric() and len(date) == 8):
        try:
            month = int(date[:2])
            day = int(date[2:4])
            year = int(date[4:])
            weekday = datetime.datetime(year, month, day).weekday()
            print('weekday')
        except ValueError:
            print('verror')
            return render(request, 'map.html', context)
    else:
        error = 'Invalid date format'
        context['error'] = error
        return render(request, 'map.html', context)
    
    if(time and len(time)==5):
        try: 
            hour = int(time[:2])
            minute = int(time[3:])
            t = hour*100+minute
            print(t)
        except ValueError:
            print('verror')
            return render(request, 'map.html', context)
    else:
        error = "Invalid time format"
        context['error'] = error
        return render(request, 'map.html', context)
    if latitude and longitude:
        latitude = float(latitude)
        longitude =float(longitude)
    else:
        error = "Invalid Coordinates"
        context['error'] = error
        return render(request, 'map.html', context)
        
    #Meter_ID is long, State_Playe is Latitude
    tmax = math.ceil(t/100)*100
    tmin = math.floor(t/100)*100
    queryset = Data.objects.filter(Issue_time__lt=tmax,Issue_time__gt=tmin)[:50000]
    mainsize = len(queryset)
    set2 = []
    for i in queryset:
        try:
            if abs(float(i.Meter_ID)-longitude) <= 0.04 and abs(float(i.State_Plate)-latitude)<=0.04:
                set2.append(i)
                
        except (TypeError, ValueError, AttributeError) as e:
            continue
    #queryset = User.objects.filter(
    locationtix = len(set2)
    daytix = 0
    for j in set2:
        if j.Issue_date.weekday()==weekday:
            daytix+=1
    print('mainsize:%d' %mainsize)
    print('locationtix:%d' % locationtix)
    print('daytix:%d' %daytix)
    if locationtix == 0:
        locationtix = 1
    
    expected = float(locationtix)/7
    estimate = (daytix - expected)/expected
    print(estimate)
    context["estimate"] = round(estimate*100, 2)
    return render(request, 'map.html', context)
