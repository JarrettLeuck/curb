from django.urls import path, include
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
	path('', views.index, name='index'),
	path('signup/', views.SignUp.as_view(), name='signup'),
	path('accounts/', views.LoginRequest, name='login'),
	path('logout/', views.logout_view, name='logout'),
	path('map/', views.map, name='map'),
	path('account/profile', views.profile_view, name='profile'),
	path('messages/', views.messages, name='messages'),
	path('citations/', views.citations, name='citations'),
	path('citations/create', views.citation_create_form, name='create'),
	path('citations/search', views.citation_search, name='search'),
	path('citations/delete', views.delete, name='delete'),
	path('citations/delete/success', views.delete_success, name='success'),
	path('citations/search/result', views.search_result, name='result'),
	path('citations/search/error', views.error, name='error'),
	path('about/', views.about, name='about'),
	path('contact/', views.contact, name='contact'),
        path('test/', views.test, name = 'test'),
]
