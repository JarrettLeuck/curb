import mysql.connector as mariadb
from pyproj import Proj, transform

mariadb_connection = mariadb.connect(user='root', password='NEWPASSWORD', database='curbdb')
cursor = mariadb_connection.cursor(buffered=True)
cursor.execute("SELECT Ticket_Num, Longitude, Latitude FROM Citation_ID")

inProj = Proj(init="epsg:2229", preserve_units=True)
outProj = Proj(init="epsg:4326")
coord = {}
for ticket, lng, lat in cursor:
    if lng and lat and lng > 6258570 and lng < 6864762 and lat > 1459957 and lat < 2187799:
        newlng, newlat = transform(inProj, outProj, long(lng), long(lat))
        coord[ticket]=(newlng, newlat)

mariadb_connection.commit()
cursor.close()
cursor = mariadb_connection.cursor(buffered=True)
for key,val in coord.items():
    #cursor.execute("SELECT Ticket_Num FROM backup_2 WHERE Ticket_Num=%s" % (key))
    cursor.execute("UPDATE Citation_ID SET Meter_ID=%s, State_Plate=%s WHERE Ticket_Num=%s" %(val[0],val[1],key))
    mariadb_connection.commit()
